package modelo;

import java.sql.*;

public class GestionConexion {

    private static Connection con;

    public static void crearConexion() throws MiExcepcion {
        if (con == null) {
            try {
                //Class.forName("com.mysql.cj.jdbc.Driver");  //MySQL
                //Class.forName("org.postgresql.Driver");   //Postgres
                Class.forName("org.apache.derby.jdbc.ClientDriver");
            } catch (ClassNotFoundException e) {
                throw new MiExcepcion(101);
            }
            
            try {
                con = DriverManager.getConnection(
                        "jdbc:derby://localhost:1527/bdcliente",
                        "bdcliente", "bdcliente");
            } catch (SQLException e) {
                throw new MiExcepcion(102);
            }
        }
    }

    public static Connection getConexion() {
        return con;
    }

    public static void cerrarConexion() {
        try {
            if (con != null) {
                con.close();
            }
        } catch (Exception e) {
        }
    }
}
