package modelo;

import java.sql.*;

public class GestionCliente {

    public static Cliente obtenerCliente(int numero) {
        Connection con = GestionConexion.getConexion();
        if (con == null) {
            return null;
        }
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(
                    "SELECT numero,nombre,edad FROM cliente WHERE numero=" + numero);
            if (rs.next()) {
                return new Cliente(
                        rs.getInt("numero"),
                        rs.getString("nombre"),
                        rs.getInt("edad"));
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
