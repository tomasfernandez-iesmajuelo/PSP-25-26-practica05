/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author bosque
 */
public class CodigosError{

    private static String mensaje;

    public static String getMensaje(int cod) {
        mensaje = "Error " + cod + ": ";
        switch (cod) {
            case 101:
                mensaje = mensaje + "al cargar los drivers de la base de datos";
                break;
            case 102:
                mensaje = mensaje + "al abrir la base de datos";
                break;
            default:
                mensaje = mensaje + "DESCONOCIDO";
        }
        return mensaje;
    }

}