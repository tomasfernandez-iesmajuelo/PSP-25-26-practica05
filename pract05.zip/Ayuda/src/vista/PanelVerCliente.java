package vista;

import javax.swing.*;
import java.awt.*;
import modelo.Cliente;

public class PanelVerCliente extends JPanel {
    // Componentes del formulario
    private JLabel labelNumero = new JLabel("Número:");
    private JLabel labelNombre = new JLabel("Nombre:");
    private JLabel labelEdad = new JLabel("Edad:");

    private JTextField fieldNumero = new JTextField(15);
    private JTextField fieldNombre = new JTextField(15);
    private JTextField fieldEdad = new JTextField(15);

    private JButton btnPrimero = new JButton("<< Primero");
    private JButton btnAnterior = new JButton("< Anterior");
    private JButton btnSiguiente = new JButton("Siguiente >");
    private JButton btnUltimo = new JButton("Último >>");
    
    private JList<String> listaCuentas = new JList<>();

    public PanelVerCliente(Principal p) {
        // El contenedor principal del Panel se establece como BorderLayout
        setLayout(new BorderLayout(10, 10)); // Espaciado de 10px entre secciones
        
        // Panel para las Etiquetas (Columna Izquierda)
        // GridLayout: 3 filas, 1 columna (vertical)
        JPanel labelPanel = new JPanel(new GridLayout(3, 1, 0, 5)); // 0 espaciado horizontal, 5px de espacio vertical
        labelPanel.add(labelNumero);
        labelPanel.add(labelNombre);
        labelPanel.add(labelEdad);
        
        // Para que las etiquetas se alineen a la derecha (cerca de los campos de texto)
        labelNumero.setHorizontalAlignment(SwingConstants.RIGHT);
        labelNombre.setHorizontalAlignment(SwingConstants.RIGHT);
        labelEdad.setHorizontalAlignment(SwingConstants.RIGHT);
        
        // Panel para los TextFields (Columna Derecha)
        // GridLayout: 3 filas, 1 columna (vertical)
        JPanel fieldPanel = new JPanel(new GridLayout(3, 1, 0, 5)); // 5px de espacio vertical
        fieldPanel.add(fieldNumero);
        fieldPanel.add(fieldNombre);
        fieldPanel.add(fieldEdad);


        // Panel de Botones (Sur) ---
        
        // FlowLayout para que los botones mantengan su tamaño preferido y se centren
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10)); // 10px de espacio entre botones
        buttonPanel.add(btnPrimero);
        buttonPanel.add(btnAnterior);
        buttonPanel.add(btnSiguiente);
        buttonPanel.add(btnUltimo);

                // --- NUEVO: Panel con lista a la derecha ---
        
        JScrollPane scrollLista = new JScrollPane(listaCuentas);

        // Tamaño preferido aproximado para ocupar 40% del ancho
        scrollLista.setPreferredSize(new Dimension(230, 0));

        // Ejemplo de datos (hay que cargarla de la BDs)
        listaCuentas.setListData(new String[]{"Cuenta 1","Cuenta 2","Cuenta 3",
                                              "Cuenta 4","Cuenta 5","Cuenta 6",
                                              "Cuenta 7","Cuenta 8","Cuenta 9"
        });
        
        
        // Añadir los paneles al contenedor principal (PanelDatosSimple) ---       
        // CENTRO: El formulario ocupa la mayor parte del espacio
        add(labelPanel, BorderLayout.WEST);
        add(fieldPanel, BorderLayout.CENTER);
        add(scrollLista, BorderLayout.EAST);
        
        // SUR: Los botones van debajo
        add(buttonPanel, BorderLayout.SOUTH);

        // Añadir un borde vacío para el margen externo del panel principal
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        Cliente c = p.getCliente();

        if (c != null) {
            System.out.println(c);
            fieldNumero.setText(c.getNumero()+"");
            fieldNombre.setText(c.getNombre());
            fieldEdad.setText(c.getEdad()+"");
        }
    }
}
