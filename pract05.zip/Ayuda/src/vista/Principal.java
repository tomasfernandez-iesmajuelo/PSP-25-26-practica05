package vista;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import modelo.Cliente;
import modelo.GestionConexion;
import modelo.MiExcepcion;
import modelo.CodigosError;

public class Principal extends JFrame {

    private Cliente clienteValidado = null;

    public Principal() {
        super("Gestión básica BDs");
        setSize(500, 250); //Tamaño fijo
        setResizable(false); // Evita que el usuario cambie el tamaño de la ventana

        setLayout(new BorderLayout());

        JMenuBar menuBar = new JMenuBar();
        JMenu menu = new JMenu("Opciones");

        JMenuItem validar = new JMenuItem("Validar");
// con expresión LAMBDA
//        validar.addActionListener(e -> {
//            setContentPane(new PanelValidar(this));
//            revalidate();
//            repaint();
//        });

// sintaxis Java TRADICIONAL: utilizando una clase anónima (Anonymous Inner Class)
        validar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // 'this' aquí se refiere a la instancia de la clase externa (Principal)
                // en cuyo constructor/método estás creando este ActionListener.
                setContentPane(new PanelValidar(Principal.this));  //Cuidao dentro de la clase anonima tengo que hacer referenca a Principal.this. Ya que this es la misma clase anónima.
                revalidate();
                repaint();
            }
        });

        JMenuItem ver = new JMenuItem("Ver cliente");
        ver.addActionListener(e -> {
            if (clienteValidado != null) {
                // El cliente existe: Cargar el panel
                setContentPane(new PanelVerCliente(this));
                // Refrescar la ventana para mostrar el nuevo panel
                revalidate();
                repaint();
            } else {
                // El cliente es nulo: Mostrar ventana emergente de alerta
                JOptionPane.showMessageDialog(
                        this, // Componente padre para que la ventana se centre
                        "No hay ningún cliente validado.", // Mensaje de alerta
                        "Error de Carga", // Título de la ventana
                        JOptionPane.WARNING_MESSAGE // Tipo de icono (Advertencia)
                );
            }
        });

        menu.add(validar);
        menu.add(ver);
        menuBar.add(menu);
        setJMenuBar(menuBar);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                GestionConexion.cerrarConexion();
            }
        });

        // Centrar la ventana: al pasar 'null', Java calcula las coordenadas para centrarla
        setLocationRelativeTo(null);

        setVisible(true);

        
// Aquí para que abra primero la aplicación
        try {
            GestionConexion.crearConexion();
        } catch (MiExcepcion ex) {
            JOptionPane.showMessageDialog(
                    this, // Componente padre para que la ventana se centre
                    CodigosError.getMensaje(ex.getCodigo()), // Obtener y mostrar e mensaje de la excepción
                    "Error de Carga", // Título de la ventana
                    JOptionPane.WARNING_MESSAGE // Tipo de icono (Advertencia)
            );
        }

    }

    public void setCliente(Cliente c) {
        this.clienteValidado = c;
    }

    public Cliente getCliente() {
        return clienteValidado;
    }
}
