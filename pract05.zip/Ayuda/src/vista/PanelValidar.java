package vista;
import javax.swing.*;
import java.awt.*;
import modelo.Cliente;
import modelo.GestionCliente;

public class PanelValidar extends JPanel {
    public PanelValidar(Principal principal){
        // BorderLayout con las secciones: Norte, Centro, Sur
        setLayout(new BorderLayout(5, 5)); // 5px de espacio vertical y horizontal
        // 1. Componentes de entrada y botón
        JTextField t = new JTextField(15);
        JButton b = new JButton("Validar");

        // 2. Etiqueta de resultado centrada
        JLabel l = new JLabel("Introduzca número para validar", SwingConstants.CENTER);
        l.setForeground(Color.BLUE); // Para diferenciar el mensaje de resultado

        // --- Panel para la Entrada y el Botón ---
        // Usamos FlowLayout para que los componentes tomen su tamaño preferido
        JPanel inputPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10)); // Centrado, con 10px de espacio
        inputPanel.add(new JLabel("Número:"));
        inputPanel.add(t);
        inputPanel.add(b);

        // --- Añadir a la Ventana Principal (PanelValidar) ---
        // NORTH: Añadimos el Panel de Entrada y Botón
        add(inputPanel, BorderLayout.NORTH);

        add(l, BorderLayout.CENTER);
        b.addActionListener(e->{
            try{
                int n=Integer.parseInt(t.getText());
                Cliente c=GestionCliente.obtenerCliente(n);
                if(c!=null){
                    principal.setCliente(c);
                    l.setText("Validado: "+c.getNombre());   
                    l.setForeground(Color.GREEN);
                }else {
                    l.setText("No encontrado");
                    l.setForeground(Color.RED);
                }
                
            }catch(Exception ex){ l.setText("Error de entrada"); }
        });
    }
}
