CREATE TABLE cliente (
    numero INT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    edad INT NOT NULL
);

INSERT INTO cliente (numero, nombre, edad) VALUES
(1, 'Ana López', 28),
(2, 'Carlos Pérez', 35),
(3, 'María Gómez', 42),
(4, 'Javier Ruiz', 31),
(5, 'Lucía Fernández', 22);

